################################################################################
# Copyright 2019-2020 Lawrence Livermore National Security, LLC and other
# Spack Project Developers. See the LICENSE file for details.
# SPDX-License-Identifier: MIT
#
# Fusion models for Atomic and molecular STructures (FAST)
# Dataset reader interface
################################################################################



import os
import numpy as np
import scipy as sp
import pandas as pd
import random
import itertools
from collections import defaultdict
import csv
import h5py
import pickle
from lib.file_util import *
from model.models_3dcnn import *
from chainer.serializers import HDF5Serializer,save_hdf5


# note:
# input_type/output_type: 0: use external reader functions (base_dir, file_name), 1: npy, 2: image file (jpg, png, etc), 3: ndarray/volume (raw, vol, npfile), 10: use the number/class in the csv (for classification, regression)
# csv_ind_output: label for classification

#data_type_default_ext = ['', 'npy', 'png', 'raw', '', '', '', '', '', '', 'txt']


class DataReader:
	def __init__(self, **kwargs):
		self.kwargs = kwargs
		self.run_mode = kwargs.get('run_mode')
		self.model_type_ind = kwargs.get('model_type_ind')
		self.feat_suffix = kwargs.get('feat_suffix')
		self.input_dim = kwargs.get('input_dim')
		self.input_3D_rotate = kwargs.get('input_3D_rotate')
		self.main_dir = kwargs.get('main_dir')
		self.model_subdir = kwargs.get('model_subdir')
		self.external_dir = kwargs.get('external_dir')
		self.external_hd_type = kwargs.get('external_hd_type')
		self.external_hd_files = kwargs.get('external_hd_files')
		self.external_csv_file = kwargs.get('external_csv_file')
		self.external_feat_prefix = kwargs.get('external_feat_prefix')
		self.input_hds = kwargs.get('input_hds')
		self.csv_header = kwargs.get('csv_header')
		self.csv_ind_input = kwargs.get('csv_ind_input')
		self.csv_ind_output = kwargs.get('csv_ind_output')
		self.csv_ind_split = kwargs.get('csv_ind_split')
		self.input_type = kwargs.get('input_type')
		self.csv_suffix = kwargs.get('csv_suffix')
		
		self.output_dim =  kwargs.get('output_dim')
		self.output_type = kwargs.get('output_type')
		self._3D_suffix = kwargs.get('_3D_suffix')
		self.input_train_hd_suffix = kwargs.get('input_train_hd_suffix')
		self.input_val_hd_suffix = kwargs.get('input_val_hd_suffix')
		self.input_test_hd_suffix = kwargs.get('input_test_hd_suffix')
		self.target_dataset = kwargs.get('target_dataset') 
		self.target_trainval_type = kwargs.get('target_trainval_type')
		self.csv_suffix = kwargs.get('csv_suffix')
		self.external_crystal_dir = kwargs.get('external_crystal_dir')
		self.external_crystal_files = kwargs.get('external_crystal_files')
		self.external_dock_eval_dir = kwargs.get('external_dock_eval_dir')
		self.num_classes = kwargs.get('num_classes')
		## process the dock eval file


		## process the rmsd file
		self.rmsd_csv_file = kwargs.get('rmsd_csv_file')
		rmsd_csv_dict1 = defaultdict(dict)
		rmsd_csv_dict2 = defaultdict(dict)
		if self.rmsd_csv_file != None:
			with open(os.path.join(self.main_dir, self.rmsd_csv_file), 'r') as csv_file:
				first_line = csv_file.readlines()[0]
				sniffer = csv.Sniffer()
				has_header = sniffer.has_header(first_line)
				csv_file.seek(0)
				csv_reader = csv.reader(csv_file)
				if has_header:
					next(csv_reader)
				o_recID = ''	
				for row in csv_reader:
					recID = row[0][:4]
					ligID = int(row[1].strip()) 
					if recID != o_recID:
						rmsd_csv_dict1[recID]['pos'] = []
						rmsd_csv_dict1[recID]['neg'] = []
						rmsd_csv_dict1[recID]['mid'] = []
						rmsd_csv_dict2[ligID]['pos'] = []
						rmsd_csv_dict2[ligID]['neg'] = []
						rmsd_csv_dict2[ligID]['mid'] = []	
					PoseID = int(row[2].strip())
					rmsd = float(row[3].strip())
					if rmsd <2:
						rmsd_csv_dict1[recID]['pos'].append((ligID,PoseID,rmsd))
						rmsd_csv_dict2[ligID]['pos'].append((recID,PoseID,rmsd))
					elif rmsd >4:
						rmsd_csv_dict1[recID]['neg'].append((ligID,PoseID,rmsd))
						rmsd_csv_dict2[ligID]['neg'].append((recID,PoseID,rmsd))
					else:
						rmsd_csv_dict1[recID]['mid'].append((ligID,PoseID,rmsd))
						rmsd_csv_dict2[ligID]['mid'].append((recID,PoseID,rmsd))
					o_recID = recID
        
		if not os.path.exists(self.external_dir):
			os.makedirs(self.external_dir)
		local_files = [os.path.join(self.external_dir,i) for i in self.external_hd_files]
		local_file_exist_ind = all([os.path.isfile(i) for i in local_files])
		if not local_file_exist_ind: 
			self.process_piece_dock_file()

		## start read in the external hd files 
		if self.run_mode == 4 or self.run_mode == 5:
			if self.external_hd_files[0].split('.')[1]=='hdf':
				for ds_ind in range(3):
					if self.external_hd_files[ds_ind] != "":
						self.input_hds[ds_ind] = h5py.File(os.path.join(self.external_dir, self.external_hd_files[ds_ind]), 'r')
			else:
				self.input_hds = [pick_load(os.path.join(self.external_dir, i)) for i in self.external_hd_files]	
			if self.external_hd_type == 2 or self.external_hd_type == 3:
				self.external_csv_file = self.external_feat_prefix + "_{}.csv".format(self.csv_suffix)
				with open(os.path.join(self.external_dir, self.external_csv_file), 'w') as csv_fp:
					csv_writer = csv.writer(csv_fp, delimiter=',')
					csv_writer.writerow(self.csv_header)
					for ds_ind, input_hd in enumerate(self.input_hds):
						if input_hd == None:
							continue
						for lig_id in input_hd.keys():
							if self.external_hd_type == 2:
								if not lig_id in rmsd_csv_dict1:
									continue
								l1 = len(rmsd_csv_dict1[lig_id]['pos'])
								l2 = len(rmsd_csv_dict1[lig_id]['neg'])
								l3 = len(rmsd_csv_dict1[lig_id]['mid'])
								if l1==0 and l2==0:
									continue
								PoseID_pos = 999 # give some fake value
								PoseID_neg = 999
								if l1>0:
									pos = random.choice(rmsd_csv_dict1[lig_id]['pos'])
									(ligID_pos,PoseID_pos,rmsd_pos) = pos 
									label_pos = 1
								if l2>0:
									neg = random.choice(rmsd_csv_dict1[lig_id]['neg'])
									(ligID_neg,PoseID_neg,rmsd_neg) = neg 
									label_neg = 0 
								
								## pose_data from docking
								
								pose_data = input_hd[lig_id]["pybel"]["processed"]["docking"]
								for pose_id in range(1,11):
                                    
									if not str(pose_id) in pose_data:
										continue
									lig_id_pose = lig_id + '_' + str(pose_id)
									lig_prefix = "%d/%s/%s" % (ds_ind, self.external_hd_files[ds_ind], lig_id_pose)
									if pose_id == PoseID_pos:
									# lig_affinity = input_hd[lig_id].attrs["affinity"]
										csv_writer.writerow([lig_id_pose, lig_prefix, label_pos, ds_ind])
									if pose_id == PoseID_neg:
										csv_writer.writerow([lig_id_pose, lig_prefix, label_neg, ds_ind])
							else:
								
									
								lig_prefix = "%d/%s/%s" % (ds_ind, self.external_hd_files[ds_ind], lig_id)
								lig_affinity = input_hd[lig_id].attrs["affinity"]
								csv_writer.writerow([lig_id, lig_prefix, lig_affinity, ds_ind])
			self.train_test_split_raw_data(self.external_dir, self.external_csv_file, self.csv_ind_input, \
				self.csv_ind_output, self.csv_ind_split, self.input_dim, self.input_type, \
					self.input_reader, self.output_dim, self.output_type, self.output_reader, num_classes=self.num_classes)					
		
		else:
			# load hd5
			if self.model_type_ind == 0 and self.input_3D_rotate == False:
				input_train_hd_file = "%s_%s_%s" % (self.feat_suffix, self._3D_suffix, self.input_train_hd_suffix)
				input_val_hd_file = "%s_%s_%s" % (self.feat_suffix, self._3D_suffix, self.input_val_hd_suffix)
				input_test_hd_file = "%s_%s_%s" % (self.feat_suffix, self._3D_suffix, self.input_test_hd_suffix)
				self.input_hds[0] = h5py.File(os.path.join(self.main_dir, input_train_hd_file), 'r')
				self.input_hds[1] = h5py.File(os.path.join(self.main_dir, input_val_hd_file), 'r')
				self.input_hds[2] = h5py.File(os.path.join(self.main_dir, input_test_hd_file), 'r')
			else:
				input_feat_train_hd_file = "%s_%s_%s" % (self.target_dataset, self.target_trainval_type, self.input_train_hd_suffix)
				input_feat_val_hd_file = "%s_%s_%s" % (self.target_dataset, self.target_trainval_type, self.input_val_hd_suffix)
				input_feat_test_hd_file = "%s_%s_core_%s" % (self.target_dataset, self.target_trainval_type, self.input_test_hd_suffix)
				self.input_hds[0] = h5py.File(os.path.join(self.main_dir, input_feat_train_hd_file), 'r')
				self.input_hds[1] = h5py.File(os.path.join(self.main_dir, input_feat_val_hd_file), 'r')
				self.input_hds[2] = h5py.File(os.path.join(self.main_dir, input_feat_test_hd_file), 'r')

			csv_file = "%s_%s_%s" % (self.feat_suffix, self._3D_suffix, self.csv_suffix)
			self.train_test_split_raw_data(self.main_dir, csv_file, self.csv_ind_input, \
				self.csv_ind_output, self.csv_ind_split, \
					self.input_dim, self.input_type, self.input_reader, \
						self.output_dim, self.output_type, self.output_reader, num_classes=self.num_classes)
	
	def process_piece_dock_file(self):
		## process the dock files
		import glob
		hd_files = glob.glob(os.path.join(self.external_dock_eval_dir, "*.hdf"))
		files = [h5py.File(i, 'r') for i in hd_files]
		dock_eval_dict = {}
		for file in files:
			keys = file.keys()
			for key in keys:
				# names = key.split('_')
				# recid = names[1]
				recid = key
				exist_ind = recid in dock_eval_dict
				# data = file[key]["pybel"]["processed"]["docking"]['1']["data"]
				data = file[key]
				if not exist_ind:
					dock_eval_dict[recid] = [(key,data)]
				else:
					dock_eval_dict[recid].append((key,data))
		
        
		input_crystals = [h5py.File(os.path.join(self.external_crystal_dir,i), 'r') for i in self.external_crystal_files]
		for ds_ind, crystal in enumerate(input_crystals):
			records = {}
			external_hd_name = self.external_hd_files[ds_ind]
			for rec_id in crystal.keys():
				this_rec_datas = dock_eval_dict.get(rec_id) 
				if this_rec_datas != None:
					for (key,data) in this_rec_datas:
						records[key] = data
			fname = os.path.join(self.external_dir,external_hd_name)
			
			## recursively walk with the file to get the data 
			records_with_data = walk_hdf5_to_dict(records)
	    
			# obj = records[key]
			# filename = os.path.join(self.external_dir,"test.hdf")
			# xx = save_hdf5(filename, obj, compression=4)
			# with h5py.File(filename, 'w') as f:
			# 	s = HDF5Serializer(f, compression=4)
			# 	s.save(obj) 
			if external_hd_name.split('.')[1]=='hdf':		
				h = h5py.File(fname, 'w')
				for key, value in records.items():
			 		if isinstance(value, h5py.Group):
			 			utf_key = key.encode('utf-8') 
					 	h.create_dataset(utf_key, data=value)
			else:
				pick_save(fname, records_with_data)

	def train_test_split_raw_data(self, main_dir, csv_fname, csv_ind_input, \
		csv_ind_output, csv_ind_split, input_dim, input_type, \
			input_reader, output_dim, output_type, \
				output_reader, num_classes=-1, \
					class_balanced=False, class_ratio=1.5):
		self.main_dir = main_dir
		self.input_dim = input_dim
		self.input_type = input_type
		self.output_dim = output_dim
		self.output_type = output_type
		self.num_classes = num_classes # for classification problem, > 0: classification
		self.class_balanced = class_balanced
		self.class_max_ratio = class_ratio
		
		self.batch_input_dim = [0 for n in range(len(self.input_dim)+1)]
		for ind, dim in enumerate(self.input_dim):
			self.batch_input_dim[ind+1] = dim

		self.batch_output_dim = [0 for n in range(len(self.output_dim)+1)]
		for ind, dim in enumerate(self.output_dim):
			self.batch_output_dim[ind+1] = dim

		self.train_list = []
		self.val_list = []
		self.test_list = []
		
		if valid_file(os.path.join(main_dir, csv_fname)):
			with open(os.path.join(main_dir, csv_fname), 'r') as csv_file:
				first_line = csv_file.readlines()[0]
				sniffer = csv.Sniffer()
				has_header = sniffer.has_header(first_line)
			
				csv_file.seek(0)
				csv_reader = csv.reader(csv_file)
				if has_header:
					next(csv_reader)
				for row in csv_reader:
					data_input_info = row[csv_ind_input] # 1 relative path from the main_dir!!!
					data_output_info = row[csv_ind_output] # 2 “lig_affinity” relative path from the main_dir or the actual label (class/number)
					data_split = int(row[csv_ind_split]) # 3
					if data_split == 0:
						self.train_list.append([data_input_info, data_output_info])
					elif data_split == 1:
						self.val_list.append([data_input_info, data_output_info])
					else:
						self.test_list.append([data_input_info, data_output_info])

		self.train_batch_ind = 0
		self.train_batch_size = 0
		self.train_batch_count = 0

		self.val_batch_ind = 0
		self.val_batch_size = 0
		self.val_batch_count = 0

		self.test_batch_ind = 0
		self.test_batch_size = 0
		self.test_batch_count = 0
			
		self.train_list_balanced = []
		self.class_max_counts = 0
		if self.class_balanced:
			train_hist, _ = self.get_class_balance_info()
			self.class_max_counts = int(float(np.min(train_hist)) * self.class_max_ratio)

	def input_reader(self, data_ind, main_dir, input_info):
		
		self.feat_tool_list = self.kwargs.get('feat_tool_list')
		self.feat_tool_ind = self.kwargs.get('feat_tool_ind')
		self.input_3D_atom_radii = self.kwargs.get('input_3D_atom_radii')
		self.input_3D_relative_size = self.kwargs.get('input_3D_relative_size')
		self.input_3D_size_angstrom = self.kwargs.get('input_3D_size_angstrom')
		 
		self.input_3D_atom_radius = self.kwargs.get('input_3D_atom_radius')
		self.input_3D_sigma = self.kwargs.get('input_3D_sigma')
		self.feat_type_list=self.kwargs.get('feat_type_list')
		self.feat_type_ind=self.kwargs.get('feat_type_ind')

		if self.external_hd_type == 1:
			split = int(input_info.split('/')[0])
			lig_id = input_info.split('/')[2]
			if self.model_type_ind == 0 and self.input_3D_rotate == False:
				input_data = self.input_hds[split][lig_id]
			else:
				tool_str = self.feat_tool_list[self.feat_tool_ind] ## pybel
				type_str = self.feat_type_list[self.feat_type_ind] ## processed
				input_data_ = self.input_hds[split][lig_id][tool_str][type_str]
				input_xyz = input_data_[:,0:3]
				input_feat = input_data_[:,3:]
				if self.model_type_ind == 0:
					if self.run_mode == 1:
						input_xyz = rotate_3D(input_xyz)
					xmin, ymin, zmin, xmax, ymax, zmax = get_3D_bound(input_xyz)
					input_data = get_3D_all2(input_xyz, input_feat, self.input_dim, \
						xmin, ymin, zmin, xmax, ymax, zmax, \
							self.input_3D_atom_radii, self.input_3D_atom_radius, self.input_3D_sigma)
				elif self.model_type_ind == 1:
					input_data = np.zeros((self.input_dim[0], self.input_dim[1]), dtype=np.float32)
					input_data[:input_feat.shape[0],:] = input_feat

		elif self.external_hd_type == 2:
			split = int(input_info.split('/')[0])
			lig_id_pose = input_info.split('/')[2]
			lig_id = '_'.join(lig_id_pose.split('_')[:1])
			pose_id = lig_id_pose.split('_')[1]
			input_hd = self.input_hds[split] ## the h5py object
			input_data_ = input_hd[lig_id]["pybel"]["processed"]["docking"][pose_id]["data"]
			
			input_radii = None
			if self.input_3D_atom_radii:
				input_radii = input_data_.attrs['van_der_waals']
			input_xyz = input_data_[:,0:3]
			input_feat = input_data_[:,3:]
			xmin, ymin, zmin, xmax, ymax, zmax = get_3D_bound(input_xyz)
			#input_data = self.get_3D_all2(input_xyz, input_feat, self.input_dim, xmin, ymin, zmin, xmax, ymax, zmax, self.input_3D_atom_radii, self.input_3D_atom_radius, self.input_3D_sigma)
			input_data = get_3D_all2(input_xyz, input_feat, self.input_dim, self.input_3D_relative_size, self.input_3D_size_angstrom, \
							input_radii, self.input_3D_atom_radius, self.input_3D_sigma)

		elif self.external_hd_type == 3:
			split = int(input_info.split('/')[0])
			lig_id = input_info.split('/')[2]
			input_hd = self.input_hds[split]
			input_data_ = input_hd[lig_id]["pybel"]["processed"]["pdbbind"]["data"]
			
			input_radii = None
			if self.input_3D_atom_radii:
				input_radii = input_data_.attrs['van_der_waals']
			input_xyz = input_data_[:,0:3]
			input_feat = input_data_[:,3:]
			xmin, ymin, zmin, xmax, ymax, zmax = get_3D_bound(input_xyz)
			#input_data = self.get_3D_all2(input_xyz, input_feat, self.input_dim, xmin, ymin, zmin, xmax, ymax, zmax, self.input_3D_atom_radii, self.input_3D_atom_radius, self.input_3D_sigma)
			input_data = get_3D_all2(input_xyz, input_feat, self.input_dim, self.input_3D_relative_size, self.input_3D_size_angstrom, \
							input_radii, self.input_3D_atom_radius, self.input_3D_sigma)

		return input_data


	def __load_input__(self, ind, input_info):
		if self.input_type == 0:
			data = self.input_reader(ind, self.main_dir, input_info)
		elif self.input_type == 1:
			data = np.load(os.path.join(self.main_dir, input_info))
			if input_info[-1] == 'z': # in case of compressed npz
				data = data["vol_data"]
		elif self.input_type == 2:
			data = sp.misc.imread(os.path.join(self.main_dir, input_info))
			data = data.reshape(self.input_dim)
		elif self.input_type == 3:
			data = np.fromfile(os.path.join(self.main_dir, input_info), dtype=np.float32)
			data = data.reshape(self.input_dim)
		elif self.input_type == 10:
			data = float(input_info)
		return data

	def output_reader(self, data_ind, main_dir, output_info):
		pass 

	def __load_output__(self, ind, output_info):
		if self.output_type == 0:
			data = self.output_reader(ind, self.main_dir, output_info)
		elif self.output_type == 1:
			data = np.load(os.path.join(self.main_dir, output_info))
		elif self.output_type == 2:
			data = sp.misc.imread(os.path.join(self.main_dir, output_info))
			data = data.reshape(self.output_dim)
		elif self.output_type == 3:
			data = np.fromfile(os.path.join(self.main_dir, output_info), dtype = np.float32)
			data = data.reshape(self.output_dim)
		elif self.output_type == 10:
			if self.num_classes > 0:
				data = int(output_info)
			else:
				data = float(output_info)
		return data

	def __save_input__(self, input, input_path): # note that it doesn't use main_dir
		if self.input_type == 0:
			print('not supported')
		elif self.input_type == 1:
			np.save(input_path, input)
		elif self.input_type == 2:
			if len(input.shape) == 3 and input.shape[2] == 1:
				input = input.reshape((input.shape[0], input.shape[1]))
			sp.misc.imsave(input_path, input)
		elif self.input_type == 3:
			input.tofile(input_path)
	
	def __save_output__(self, output, output_path): # note that it doesn't use main_dir
		if self.output_type == 0:
			print('not supported')
		elif self.output_type == 1:
			np.save(output_path, output)
		elif self.output_type == 2:
			if len(output.shape) == 3 and output.shape[2] == 1:
				output = output.reshape((output.shape[0], output.shape[1]))
			sp.misc.imsave(output_path, output)
		elif self.output_type == 3:
			output.tofile(output_path)

	def begin_train(self, batch_size, shuffle:True):
		self.train_batch_ind = 0
		self.train_batch_size = batch_size
		self.batch_input_dim[0] = self.train_batch_size # the first dimension is always for batch
		self.batch_output_dim[0] = self.train_batch_size
		self.input_batch  = np.zeros(self.batch_input_dim, dtype=np.float32)
		if self.num_classes > 0:
			self.output_batch = np.zeros((self.train_batch_size), dtype=np.int32)
		else:
			self.output_batch = np.zeros(self.batch_output_dim, dtype=np.float32)
		if shuffle:
			random.shuffle(self.train_list)
		
		if self.class_balanced:
			self.train_list_balanced = []
			class_count = [0 for n in range(self.num_classes)]
			for input_info, output_info in self.train_list:
				label = int(output_info)
				if class_count[label] > self.class_max_counts:
					continue
				self.train_list_balanced.append([input_info, output_info])
				class_count[label] += 1
			random.shuffle(self.train_list_balanced)
			self.train_batch_count = int(len(self.train_list_balanced) // batch_size)
		else:
			self.train_batch_count = int(len(self.train_list) // batch_size)

	def next_train(self):
		for n in range(self.train_batch_size):
			ind = n + self.train_batch_ind * self.train_batch_size
			if self.class_balanced:
				input_info, output_info = self.train_list_balanced[ind]
			else:
				input_info, output_info = self.train_list[ind]
			self.input_batch[n] = self.__load_input__(ind, input_info)
			self.output_batch[n] = self.__load_output__(ind, output_info)
		
		self.train_batch_ind = (self.train_batch_ind+1) % self.train_batch_count
		return self.input_batch, self.output_batch

	def begin_val(self, batch_size):
		self.val_batch_ind = 0
		self.val_batch_size = batch_size
		self.val_batch_count = int(len(self.val_list) // batch_size)
		self.batch_input_dim[0] = self.val_batch_size
		self.batch_output_dim[0] = self.val_batch_size
		
		self.input_batch  = np.zeros(self.batch_input_dim, dtype=np.float32)
		if self.num_classes > 0:
			self.output_batch = np.zeros((self.val_batch_size), dtype=np.int32)
		else:
			self.output_batch = np.zeros(self.batch_output_dim, dtype=np.float32)
	
	def next_val(self):
		for n in range(self.val_batch_size):
			ind = n + self.val_batch_ind * self.val_batch_size
			input_info, output_info = self.val_list[ind]
			self.input_batch[n] = self.__load_input__(ind, input_info)
			self.output_batch[n] = self.__load_output__(ind, output_info)
		
		self.val_batch_ind = (self.val_batch_ind+1) % self.val_batch_count
		return self.input_batch, self.output_batch

	def begin_test(self, batch_size):
		self.test_batch_ind = 0
		self.test_batch_size = batch_size
		self.test_batch_count = int(len(self.test_list) // batch_size)
		self.batch_input_dim[0] = self.test_batch_size
		self.batch_output_dim[0] = self.test_batch_size
		
		self.input_batch  = np.zeros(self.batch_input_dim, dtype=np.float32)
		if self.num_classes > 0:
			self.output_batch = np.zeros((self.test_batch_size), dtype=np.int32)
		else:
			self.output_batch = np.zeros(self.batch_output_dim, dtype=np.float32)
	
	def next_test(self):
		for n in range(self.test_batch_size):
			ind = n + self.test_batch_ind * self.test_batch_size
			input_info, output_info = self.test_list[ind]
			self.input_batch[n] = self.__load_input__(ind, input_info)
			self.output_batch[n] = self.__load_output__(ind, output_info)
		
		self.test_batch_ind = (self.test_batch_ind+1) % self.test_batch_count
		return self.input_batch, self.output_batch

	def get_test(self, test_inds):
		indim = [0 for n in range(len(self.input_dim)+1)]
		indim[0] = len(test_inds)
		for ind, dim in enumerate(self.input_dim):
			indim[ind+1] = dim

		outdim = [0 for n in range(len(self.output_dim)+1)]
		outdim[0] = len(test_inds)
		for ind, dim in enumerate(self.output_dim):
			outdim[ind+1] = dim
	
		inbatch = np.zeros(indim, dtype=np.float32)
		if self.num_classes > 0:
			outbatch = np.zeros((len(test_inds)), dtype=np.int32)
		else:
			outbatch = np.zeros(outdim, dtype=np.float32)
		
		infobatch = []
		for n, ind in enumerate(test_inds):
			input_info, output_info = self.test_list[ind]
			inbatch[n] = self.__load_input__(ind, input_info)
			outbatch[n] = self.__load_output__(ind, output_info)
			infobatch.append([input_info, output_info])
		
		return inbatch, outbatch, infobatch

	def get_class_balance_info(self):
		if self.num_classes <= 0:
			return [], []
		train_data_hist = [0 for n in range(self.num_classes)]
		val_data_hist = [0 for n in range(self.num_classes)]
		test_data_hist = [0 for n in range(self.num_classes)]
		for (_, output_info) in self.train_list:
			train_data_hist[int(output_info)] += 1
		for (_, output_info) in self.val_list:
			val_data_hist[int(output_info)] += 1
		for (_, output_info) in self.test_list:
			test_data_hist[int(output_info)] += 1
		return train_data_hist, test_data_hist
















class MetricDataReader:
	def __init__(self, main_dir, csv_fname, csv_ind_input1, csv_ind_input2, csv_ind_label, csv_ind_split, input_dim, input_type, input_reader:None):
		a = 0 #########






#class Dataset_ATOM_Pair:
#	def __init__(self, main_dir:'', train_subdir:'', test_subdir:'', input_dim:[64,64,64,8], label_mode:2):
#		self.train_dir = os.path.join(main_dir, train_subdir)
#		self.test_dir = os.path.join(main_dir, test_subdir)
#		self.num_classes = 2 # same or not (1, 0)
#		self.input_dim = input_dim
#		self.label_mode = label_mode
#		
#		self.train_pos_list = []
#		self.train_neg_list = []
#		self.train_batch_ind = 0
#		self.train_batch_size = 0
#		self.train_batch_count = 0
#		
#		self.test_pos_list = []
#		self.test_neg_list = []
#		self.test_batch_ind = 0
#		self.test_batch_size = 0
#		self.test_batch_count = 0
#	
#		file_list = get_files_ext(self.train_dir, 'vol')
#		for file_name in file_list:
#			if self.label_mode == 1:
#				if file_name.startswith('act'):
#					self.train_pos_list.append(file_name)
#				else:
#					self.train_neg_list.append(file_name)
#			elif self.label_mode == 2:
#				label = int(file_name[-5:-4])
#				if label == 0 or label == 1:
#					self.train_neg_list.append(file_name)
#				else:
#					self.train_pos_list.append(file_name)
#
#		file_list = get_files_ext(self.test_dir, 'vol')
#		for file_name in file_list:
#			if self.label_mode == 1:
#				if file_name.startswith('act'):
#					self.train_pos_list.append(file_name)
#				else:
#					self.train_neg_list.append(file_name)
#			elif self.label_mode == 2:
#				label = int(file_name[-5:-4])
#				if label == 0 or label == 1:
#					self.train_neg_list.append(file_name)
#				else:
#					self.train_pos_list.append(file_name)
#
#	def __load_vol__(self, vol_filename):
#		vol_data = np.fromfile(vol_filename, dtype = np.float32)
#		vol_data = vol_data.reshape([self.input_dim[0], self.input_dim[1], self.input_dim[2], self.input_dim[3]])
#		return vol_data
#
#	def begin_train(self, batch_size):
#		random.shuffle(self.train_pos_list)
#		random.shuffle(self.train_neg_list)
#		
#		self.train_pospair_list = []
#		self.train_pospair_list.extend(list(itertools.combinations(self.train_pos_list, 2))[:max_pair_count])
#		self.train_pospair_list.extend(list(itertools.combinations(self.train_neg_list, 2))[:max_pair_count])
#		
#		self.train_negpair_list = []
#		while len(self.train_negpair_list) < len(self.train_pospair_list):
#			for train_pos_item in self.train_pos_list:
#				self.train_negpair_list.append((train_pos_item, random.choice(self.train_neg_list)))
#			for train_neg_item in self.train_neg_list:
#				self.train_negpair_list.append((train_neg_item, random.choice(self.train_pos_list)))
#		self.train_negpair_list = self.train_negpair_list[:len(self.train_pospair_list)]
#
#		self.train_batch_ind = 0
#		self.train_batch_size = batch_size
#		self.train_batch_count = (len(self.train_pospair_list) * 2) / batch_size
#
#	def next_train(self):
#		vol_batch1 = np.zeros((self.train_batch_size, self.input_dim[0], self.input_dim[1], self.input_dim[2], self.input_dim[3]), dtype=np.float32)
#		vol_batch2 = np.zeros((self.train_batch_size, self.input_dim[0], self.input_dim[1], self.input_dim[2], self.input_dim[3]), dtype=np.float32)
#		label_batch = np.zeros((self.train_batch_size), dtype=np.int32)
#
#		noffset = self.train_batch_ind * self.train_batch_size / 2
#		for n in range(self.train_batch_size):
#			ind = (noffset + n) / 2
#			if n % 2 == 0:
#				(file_name1, file_name2) = self.train_pospair_list[ind]
#				label = 1
#			else:
#				(file_name1, file_name2) = self.train_negpair_list[ind]
#				label = 0
#			
#			vol_batch1[n,:,:,:,:] = self.__load_vol__(os.path.join(self.train_dir, file_name1))
#			vol_batch2[n,:,:,:,:] = self.__load_vol__(os.path.join(self.train_dir, file_name2))
#			label_batch[n] = label
#
#		self.train_batch_ind = (self.train_batch_ind+1) % self.train_batch_count
#		return vol_batch1, vol_batch2, label_batch
#
#	def begin_test(self, batch_size):
#		self.test_pospair_list = []
#		self.test_pospair_list.extend(list(itertools.combinations(self.test_pos_list, 2))[:max_pair_count])
#		self.test_pospair_list.extend(list(itertools.combinations(self.test_neg_list, 2))[:max_pair_count])
#		
#		self.test_negpair_list = []
#		while len(self.test_negpair_list) < len(self.test_pospair_list):
#			for test_pos_item in self.test_pos_list:
#				self.test_negpair_list.append((test_pos_item, random.choice(self.test_neg_list)))
#			for test_neg_item in self.test_neg_list:
#				self.test_negpair_list.append((test_neg_item, random.choice(self.test_pos_list)))
#		self.test_negpair_list = self.test_negpair_list[:len(self.test_pospair_list)]
#		
#		self.test_batch_ind = 0
#		self.test_batch_size = batch_size
#		self.test_batch_count = (len(self.test_pospair_list) + len(self.test_pospair_list)) / batch_size
#
#	def next_test(self):
#		vol_batch1 = np.zeros((self.test_batch_size, self.input_dim[0], self.input_dim[1], self.input_dim[2], self.input_dim[3]), dtype=np.float32)
#		vol_batch2 = np.zeros((self.test_batch_size, self.input_dim[0], self.input_dim[1], self.input_dim[2], self.input_dim[3]), dtype=np.float32)
#		label_batch = np.zeros((self.test_batch_size), dtype=np.int32)
#
#		noffset = self.test_batch_ind * self.test_batch_size
#		for n in range(self.test_batch_size):
#			ind = noffset + n
#			if ind < len(self.test_pospair_list):
#				(file_name1, file_name2) = self.test_pospair_list[ind]
#				label = 1
#			else:
#				(file_name1, file_name2) = self.test_negpair_list[ind - len(self.test_pospair_list)]
#				label = 0
#
#			vol_batch1[n,:,:,:,:] = self.__load_vol__(os.path.join(self.test_dir, file_name1))
#			vol_batch2[n,:,:,:,:] = self.__load_vol__(os.path.join(self.test_dir, file_name2))
#			label_batch[n] = label
#		
#		self.test_batch_ind = (self.test_batch_ind+1) % self.test_batch_count
#		return vol_batch1, vol_batch2, label_batch
#
#
#if __name__ == '__main__':
##	data_reader = Dataset_ATOM('/Users/kim63/LLNL/Data/ATOM/Try1_dataset_3d/', 'cnn_3d_180222_train', 'cnn_3d_180222_test')
##	data_reader.begin_train(50)
##	for batch_ind in range(data_reader.train_batch_count):
##		x_batch, y_batch = data_reader.next_train()
##		print('%d/%d' % (batch_ind, data_reader.train_batch_count))
##		print(x_batch.shape)
##		print(y_batch.shape)
##		print(y_batch)
##	data_reader.begin_test(50)
##	for batch_ind in range(data_reader.test_batch_count):
##		x_batch, y_batch = data_reader.next_test()
##		print(x_batch.shape)
##		print(y_batch.shape)
##		print(y_batch)
#
#	data_reader_pair = Dataset_ATOM_Pair('/Users/kim63/LLNL/Data/ATOM/Try1_dataset_3d/', 'cnn_3d_180222_train', 'cnn_3d_180222_test')
#	data_reader_pair.begin_train(100)
#	#for batch_ind in range(data_reader_pair.train_batch_count):
#	#	x_batch1, x_batch2, y_batch = data_reader_pair.next_train()
#	#	print('%d/%d' % (batch_ind, data_reader_pair.train_batch_count))
#	#	print(batch_ind)
#	#	print(x_batch1.shape)
#	#	print(x_batch2.shape)
#	#	print(y_batch)
#
#	data_reader_pair.begin_test(100)
#	for batch_ind in range(data_reader_pair.test_batch_count):
#		x_batch1, x_batch2, y_batch = data_reader_pair.next_test()
#		print('%d/%d' % (batch_ind, data_reader_pair.test_batch_count))
#		print(batch_ind)
#		print(x_batch1.shape)
#		print(x_batch2.shape)
#		print(y_batch)


################################################################################
# Copyright 2019-2020 Lawrence Livermore National Security, LLC and other
# Spack Project Developers. See the LICENSE file for details.
# SPDX-License-Identifier: MIT
#
# Fusion models for Atomic and molecular STructures (FAST)
# File utility functions
################################################################################


import os
import pickle
import h5py

def pick_load(name):
    with open(name, 'rb') as input:
        obj = pickle.load(input)
    return obj 

def pick_save(name, obj):
		with open(name, 'wb') as output:
			pickle.dump(obj, output)    

def walk_hdf5_to_dict(h5):
	dic = {}
	for key, value in h5.items():
		if isinstance(value, h5py.Group):
			dic[key] = walk_hdf5_to_dict(value)
		elif isinstance(value, h5py.Dataset):
			dic[key] = value[()]
		else:
			print('what are you?', type(value))
	return dic 

def get_files(a_dir):
	return [name for name in os.listdir(a_dir) if os.path.isfile(os.path.join(a_dir, name))]

def get_files_prefix(a_dir, a_prefix):
	return [name for name in os.listdir(a_dir) if os.path.isfile(os.path.join(a_dir, name)) and name.startswith(a_prefix)]

def get_files_ext(a_dir, a_ext):
	return [name for name in os.listdir(a_dir) if os.path.isfile(os.path.join(a_dir, name)) and name.endswith(a_ext)]

def get_files_prefix_ext(a_dir, a_prefix, a_ext):
	return [name for name in os.listdir(a_dir) if os.path.isfile(os.path.join(a_dir, name)) and name.startswith(a_prefix) and name.endswith(a_ext)]

def get_subdirectories(a_dir):
	return [name for name in os.listdir(a_dir) if os.path.isdir(os.path.join(a_dir, name))]

def get_subdirectories_prefix(a_dir, a_prefix):
	return [name for name in os.listdir(a_dir) if os.path.isdir(os.path.join(a_dir, name)) and name.startswith(a_prefix)]

def valid_file(a_path):
	return os.path.isfile(a_path) and os.path.getsize(a_path) > 0

import tensorflow as tf
import scipy as sp
from lib.tf_util import *
def rotate_3D(input_data):
	rotation_angle = np.random.uniform() * 2 * np.pi
	cosval = np.cos(rotation_angle)
	sinval = np.sin(rotation_angle)
	rotation_matrix = np.array([[cosval, 0, sinval], [0, 1, 0], [-sinval, 0, cosval]])
	#rotated_data = np.zeros(input_data.shape, dtype=np.float32)
	rotated_data = np.dot(input_data, rotation_matrix)
	return rotated_data


def get_3D_bound(xyz_array):
    xmin = min(xyz_array[:, 0])
    ymin = min(xyz_array[:, 1])
    zmin = min(xyz_array[:, 2])
    xmax = max(xyz_array[:, 0])
    ymax = max(xyz_array[:, 1])
    zmax = max(xyz_array[:, 2])
    return xmin, ymin, zmin, xmax, ymax, zmax


def get_3D_all2__(xyz, feat, vol_dim, xmin, ymin, zmin, xmax, ymax, zmax, atom_radii:None, atom_radius:1, sigma:0):

	# initialize volume
	vol_data = np.zeros((vol_dim[0], vol_dim[1], vol_dim[2], vol_dim[3]), dtype=np.float32)

	# voxel size (assum voxel size is the same in all axis
	vox_size = (zmax - zmin) / vol_dim[0]

	# assign each atom to voxels
	for ind in range(xyz.shape[0]):
		x = xyz[ind, 0]
		y = xyz[ind, 1]
		z = xyz[ind, 2]
		if x < xmin or x > xmax or y < ymin or y > ymax or z < zmin or z > zmax:
			continue

		# compute van der Waals radius and atomic density, use 1 if not available
		if not atom_radii is None:
			vdw_radius = atom_radii[ind]
			atom_radius = 1 + vdw_radius * vox_size

		cx = (x - xmin) / (xmax - xmin) * (vol_dim[2] - 1)
		cy = (y - ymin) / (ymax - ymin) * (vol_dim[1] - 1)
		cz = (z - zmin) / (zmax - zmin) * (vol_dim[0] - 1)

		vx_from = max(0, int(cx - atom_radius))
		vx_to = min(vol_dim[2] - 1, int(cx + atom_radius))
		vy_from = max(0, int(cy - atom_radius))
		vy_to = min(vol_dim[1] - 1, int(cy + atom_radius))
		vz_from = max(0, int(cz - atom_radius))
		vz_to = min(vol_dim[0] - 1, int(cz + atom_radius))

		for vz in range(vz_from, vz_to + 1):
			for vy in range(vy_from, vy_to + 1):
				for vx in range(vx_from, vx_to + 1):
						vol_data[vz, vy, vx, :] += feat[ind, :]

	# gaussian filter
	if sigma > 0:
		for i in range(vol_data.shape[-1]):
			vol_data[:,:,:,i] = sp.ndimage.filters.gaussian_filter(vol_data[:,:,:,i], sigma=sigma, truncate=2)

	return vol_data
	

def get_3D_all2(xyz, feat, vol_dim, relative_size=True, size_angstrom=48, atom_radii=None, atom_radius=1, sigma=0):

	# get 3d bounding box
	xmin, ymin, zmin, xmax, ymax, zmax = get_3D_bound(xyz)
	
	# initialize volume
	vol_data = np.zeros((vol_dim[0], vol_dim[1], vol_dim[2], vol_dim[3]), dtype=np.float32)

	if relative_size:
		# voxel size (assum voxel size is the same in all axis
		vox_size = float(zmax - zmin) / float(vol_dim[0])
	else:
		vox_size = float(size_angstrom) / float(vol_dim[0])
		xmid = (xmin + xmax) / 2.0
		ymid = (ymin + ymax) / 2.0
		zmid = (zmin + zmax) / 2.0
		xmin = xmid - (size_angstrom / 2)
		ymin = ymid - (size_angstrom / 2)
		zmin = zmid - (size_angstrom / 2)
		xmax = xmid + (size_angstrom / 2)
		ymax = ymid + (size_angstrom / 2)
		zmax = zmid + (size_angstrom / 2)
		vox_size2 = float(size_angstrom) / float(vol_dim[0])
		#print(vox_size, vox_size2)

	# assign each atom to voxels
	for ind in range(xyz.shape[0]):
		x = xyz[ind, 0]
		y = xyz[ind, 1]
		z = xyz[ind, 2]
		if x < xmin or x > xmax or y < ymin or y > ymax or z < zmin or z > zmax:
			continue

		# compute van der Waals radius and atomic density, use 1 if not available
		if not atom_radii is None:
			vdw_radius = atom_radii[ind]
			atom_radius = 1 + vdw_radius * vox_size

		cx = (x - xmin) / (xmax - xmin) * (vol_dim[2] - 1)
		cy = (y - ymin) / (ymax - ymin) * (vol_dim[1] - 1)
		cz = (z - zmin) / (zmax - zmin) * (vol_dim[0] - 1)

		vx_from = max(0, int(cx - atom_radius))
		vx_to = min(vol_dim[2] - 1, int(cx + atom_radius))
		vy_from = max(0, int(cy - atom_radius))
		vy_to = min(vol_dim[1] - 1, int(cy + atom_radius))
		vz_from = max(0, int(cz - atom_radius))
		vz_to = min(vol_dim[0] - 1, int(cz + atom_radius))

		for vz in range(vz_from, vz_to + 1):
			for vy in range(vy_from, vy_to + 1):
				for vx in range(vx_from, vx_to + 1):
						vol_data[vz, vy, vx, :] += feat[ind, :]

	# gaussian filter
	if sigma > 0:
		for i in range(vol_data.shape[-1]):
			vol_data[:,:,:,i] = sp.ndimage.filters.gaussian_filter(vol_data[:,:,:,i], sigma=sigma, truncate=2)

	return vol_data


def model_3dcnn(model_name, img_data, train_mode, reuse):
	with tf.variable_scope(model_name, reuse=reuse):
		x = img_data
		print(x.shape)
		
		conv1_w = weight_var_selu([7,7,7,input_dim[3],96],name="conv1_w")
		conv1_b = bias_var([96],name="conv1_b")
		conv1_z = conv3d(x, conv1_w, strides=(1,2,2,2,1)) + conv1_b
		conv1_h = bn(tf.nn.relu(conv1_z), train_mode,"conv1_bn")
		print(conv1_h.shape)

		conv2_w = weight_var_selu([7,7,7,96,128],name="conv2_w")
		conv2_b = bias_var([128],name="conv2_b")
		conv2_z = conv3d(conv1_h, conv2_w, strides=(1,3,3,3,1)) + conv2_b
		conv2_h = bn(tf.nn.relu(conv2_z), train_mode,"conv2_bn")
		print(conv2_h.shape)
		
		pool2_h = avg_pool_2x2x2(conv2_h)
		print(pool2_h.shape)
		
		conv3_w = weight_var_selu([5,5,5,128,128],name="conv3_w")
		conv3_b = bias_var([128],name="conv3_b")
		conv3_z = conv3d(pool2_h, conv3_w, strides=(1,2,2,2,1)) + conv3_b
		conv3_h = bn(tf.nn.relu(conv3_z), train_mode,"conv3_bn")
		print(conv3_h.shape)
		
		pool3_h = avg_pool_2x2x2(conv3_h)
		print(pool3_h.shape)
		
		pool3_h_dim = (pool3_h.shape[1] * pool3_h.shape[2] * pool3_h.shape[3] * pool3_h.shape[4])
		flatten_h = tf.reshape(pool3_h, [tf.shape(pool3_h)[0], int(pool3_h_dim)])
		print(flatten_h.shape)
		
		#fc1_w = weight_var([int(flatten_h.shape[1]), 2], stddev=0.01, name="fc1_w")
		#fc1_b = bias_var([2], name="fc1_b")
		#fc1_z = tf.matmul(flatten_h, fc1_w) + fc1_b
		#print(fc1_z.shape)
	#return fc1_z

		fc1_w = weight_var([int(flatten_h.shape[1]), 10], stddev=0.01, name="fc1_w")
		fc1_b = bias_var([10], name="fc1_b")
		fc1_z = tf.matmul(flatten_h, fc1_w) + fc1_b
		fc1_h = bn(tf.nn.relu(fc1_z), train_mode,"fc1_bn")
		print(fc1_h.shape)

		fc2_w = weight_var([10, 1], stddev=0.01, name="fc2_w")
		fc2_b = bias_var([1], name="fc2_b")
		fc2_z = tf.matmul(fc1_h, fc2_w) + fc2_b
		print(fc2_z.shape)
			
	return fc2_z


def model_3dcnn_res(model_name, img_data, train_mode, reuse, args):
	if args.feat_tool_ind == 0:
		num_filters = [64, 128, 256]
	else:
		num_filters = [96, 128, 128]

	with tf.variable_scope(model_name, reuse=reuse):
		x = img_data
		print(x.shape)
		
		conv1_w = weight_var_selu([7,7,7,args.input_dim[3],num_filters[0]],name="conv1_w")
		conv1_b = bias_var([num_filters[0]],name="conv1_b")
		conv1_z = conv3d(x, conv1_w, strides=(1,2,2,2,1)) + conv1_b
		conv1_h = bn(tf.nn.relu(conv1_z), train_mode,"conv1_bn")
		print(conv1_h.shape)
		
		conv1_res1_w = weight_var_selu([7,7,7,num_filters[0],num_filters[0]], name="conv1_res1_w")
		conv1_res1_b = bias_var([num_filters[0]], name="conv1_res1_b")
		conv1_res1_z = conv3d(conv1_h, conv1_res1_w, strides=(1,1,1,1,1)) + conv1_res1_b
		conv1_res1_h = bn(tf.nn.relu(conv1_res1_z), train_mode,"conv1_res1_bn")
		print(conv1_res1_h.shape)
		conv1_res1_h2 = conv1_res1_h + conv1_h
		print(conv1_res1_h2.shape)
		
		conv1_res2_w = weight_var_selu([7,7,7,num_filters[0],num_filters[0]], name="conv1_res2_w")
		conv1_res2_b = bias_var([num_filters[0]], name="conv1_res2_b")
		conv1_res2_z = conv3d(conv1_res1_h2, conv1_res2_w, strides=(1,1,1,1,1)) + conv1_res2_b
		conv1_res2_h = bn(tf.nn.relu(conv1_res2_z), train_mode,"conv1_res2_bn")
		print(conv1_res2_h.shape)
		conv1_res2_h2 = conv1_res2_h + conv1_h
		print(conv1_res2_h2.shape)
		
		conv2_w = weight_var_selu([7,7,7,num_filters[0],num_filters[1]],name="conv2_w")
		conv2_b = bias_var([num_filters[1]],name="conv2_b")
		conv2_z = conv3d(conv1_res2_h2, conv2_w, strides=(1,3,3,3,1)) + conv2_b
		conv2_h = bn(tf.nn.relu(conv2_z), train_mode, "conv2_bn")
		print(conv2_h.shape)
		
		pool2_h = avg_pool_2x2x2(conv2_h)
		print(pool2_h.shape)
		
		conv3_w = weight_var_selu([5,5,5,num_filters[1],num_filters[2]],name="conv3_w")
		conv3_b = bias_var([num_filters[2]],name="conv3_b")
		conv3_z = conv3d(pool2_h, conv3_w, strides=(1,2,2,2,1)) + conv3_b
		conv3_h = bn(tf.nn.relu(conv3_z), train_mode, "conv3_bn")
		print(conv3_h.shape)
		
		pool3_h = avg_pool_2x2x2(conv3_h)
		print(pool3_h.shape)
		
		pool3_h_dim = (pool3_h.shape[1] * pool3_h.shape[2] * pool3_h.shape[3] * pool3_h.shape[4])
		flatten_h = tf.reshape(pool3_h, [tf.shape(pool3_h)[0], int(pool3_h_dim)], name="flatten_h")
		print(flatten_h.shape)
		
		#fc1_w = weight_var([int(flatten_h.shape[1]), 2], stddev=0.01, name="fc1_w")
		#fc1_b = bias_var([2], name="fc1_b")
		#fc1_z = tf.matmul(flatten_h, fc1_w) + fc1_b
		#print(fc1_z.shape)
		#return fc1_z
		
		fc1_w = weight_var([int(flatten_h.shape[1]), 10], stddev=0.01, name="fc1_w")
		fc1_b = bias_var([10], name="fc1_b")
		fc1_z = tf.matmul(flatten_h, fc1_w) + fc1_b
		fc1_y = tf.nn.relu(fc1_z)
		fc1_h = bn(fc1_y, train_mode, "fc1_bn")
		print(fc1_h.shape)
		
		fc2_w = weight_var([10, 1], stddev=0.01, name="fc2_w")
		fc2_b = bias_var([1], name="fc2_b")
		fc2_z = tf.matmul(fc1_h, fc2_w) + fc2_b
		print(fc2_z.shape)
	
	return fc2_z, [fc1_h, fc1_y, fc1_z, flatten_h, pool3_h, conv3_h, pool2_h, conv2_h, conv1_res2_h2, conv1_res2_h, conv1_res1_h2, conv1_res1_h, conv1_h]






def model_3dcnn_res2(model_name, img_data, train_mode, reuse):
	with tf.variable_scope(model_name, reuse=reuse):
		x = img_data
		print(x.shape)
		
		conv1_w = weight_var_selu([7,7,7,input_dim[3],96],name="conv1_w")
		conv1_b = bias_var([96],name="conv1_b")
		conv1_z = conv3d(x, conv1_w, strides=(1,2,2,2,1)) + conv1_b
		conv1_h = bn(tf.nn.relu(conv1_z), train_mode,"conv1_bn")
		print(conv1_h.shape)
		
		conv1_res1_w = weight_var_selu([7,7,7,96,96], name="conv1_res1_w")
		conv1_res1_b = bias_var([96], name="conv1_res1_b")
		conv1_res1_z = conv3d(conv1_h, conv1_res1_w, strides=(1,1,1,1,1)) + conv1_res1_b
		conv1_res1_h = bn(tf.nn.relu(conv1_res1_z), train_mode,"conv1_res1_bn")
		print(conv1_res1_h.shape)
		conv1_res1_h2 = conv1_res1_h + conv1_h
		print(conv1_res1_h2.shape)
		
		conv1_res2_w = weight_var_selu([5,5,5,96,96], name="conv1_res2_w")
		conv1_res2_b = bias_var([96], name="conv1_res2_b")
		conv1_res2_z = conv3d(conv1_res1_h2, conv1_res2_w, strides=(1,1,1,1,1)) + conv1_res2_b
		conv1_res2_h = bn(tf.nn.relu(conv1_res2_z), train_mode,"conv1_res2_bn")
		print(conv1_res2_h.shape)
		conv1_res2_h2 = conv1_res2_h + conv1_h
		print(conv1_res2_h2.shape)

		conv1_res3_w = weight_var_selu([3,3,3,96,96], name="conv1_res3_w")
		conv1_res3_b = bias_var([96], name="conv1_res3_b")
		conv1_res3_z = conv3d(conv1_res2_h2, conv1_res3_w, strides=(1,1,1,1,1)) + conv1_res3_b
		conv1_res3_h = bn(tf.nn.relu(conv1_res3_z), train_mode,"conv1_res3_bn")
		print(conv1_res3_h.shape)
		conv1_res3_h2 = conv1_res3_h + conv1_h
		print(conv1_res3_h2.shape)

		conv2_w = weight_var_selu([5,5,5,96,96],name="conv2_w")
		conv2_b = bias_var([96],name="conv2_b")
		conv2_z = conv3d(conv1_res3_h2, conv2_w, strides=(1,3,3,3,1)) + conv2_b
		conv2_h = bn(tf.nn.relu(conv2_z), train_mode, "conv2_bn")
		print(conv2_h.shape)
		
		pool2_h = max_pool_2x2x2(conv2_h)
		print(pool2_h.shape)
		
		conv3_w = weight_var_selu([3,3,3,96,128],name="conv3_w")
		conv3_b = bias_var([128],name="conv3_b")
		conv3_z = conv3d(pool2_h, conv3_w, strides=(1,2,2,2,1)) + conv3_b
		conv3_h = bn(tf.nn.relu(conv3_z), train_mode, "conv3_bn")
		print(conv3_h.shape)
		
		pool3_h = max_pool_2x2x2(conv3_h)
		print(pool3_h.shape)
		
		pool3_h_dim = (pool3_h.shape[1] * pool3_h.shape[2] * pool3_h.shape[3] * pool3_h.shape[4])
		flatten_h = tf.reshape(pool3_h, [tf.shape(pool3_h)[0], int(pool3_h_dim)], name="flatten_h")
		print(flatten_h.shape)
		
		#fc1_w = weight_var([int(flatten_h.shape[1]), 2], stddev=0.01, name="fc1_w")
		#fc1_b = bias_var([2], name="fc1_b")
		#fc1_z = tf.matmul(flatten_h, fc1_w) + fc1_b
		#print(fc1_z.shape)
		#return fc1_z
		
		fc1_w = weight_var([int(flatten_h.shape[1]), 10], stddev=0.01, name="fc1_w")
		fc1_b = bias_var([10], name="fc1_b")
		fc1_z = tf.matmul(flatten_h, fc1_w) + fc1_b
		fc1_h = bn(tf.nn.relu(fc1_z), train_mode, "fc1_bn")
		print(fc1_h.shape)
		
		fc2_w = weight_var([10, 1], stddev=0.01, name="fc2_w")
		fc2_b = bias_var([1], name="fc2_b")
		fc2_z = tf.matmul(fc1_h, fc2_w) + fc2_b
		print(fc2_z.shape)
	
	return fc2_z, [fc1_h, fc1_z, flatten_h, pool3_h, conv3_h, pool2_h, conv2_h, conv1_res2_h2, conv1_res2_h, conv1_res1_h2, conv1_res1_h, conv1_h]


def model_3dcnn_res3(model_name, img_data, train_mode, reuse):
	with tf.variable_scope(model_name, reuse=reuse):
		x = img_data
		print(x.shape)
		
		conv1_w = weight_var_selu([7,7,7,input_dim[3],96],name="conv1_w")
		conv1_b = bias_var([96],name="conv1_b")
		conv1_z = conv3d(x, conv1_w, strides=(1,2,2,2,1)) + conv1_b
		conv1_h = bn(tf.nn.relu(conv1_z), train_mode,"conv1_bn")
		print(conv1_h.shape)

		conv1_res1_w = weight_var_selu([7,7,7,96,96], name="conv1_res1_w")
		conv1_res1_b = bias_var([96], name="conv1_res1_b")
		conv1_res1_z = conv3d(conv1_h, conv1_res1_w, strides=(1,1,1,1,1)) + conv1_res1_b
		conv1_res1_h = bn(tf.nn.relu(conv1_res1_z), train_mode,"conv1_res1_bn")
		print(conv1_res1_h.shape)
		conv1_res1_h2 = conv1_res1_h + conv1_h
		print(conv1_res1_h2.shape)
		
		conv1_res2_w = weight_var_selu([5,5,5,96,96], name="conv1_res2_w")
		conv1_res2_b = bias_var([96], name="conv1_res2_b")
		conv1_res2_z = conv3d(conv1_res1_h2, conv1_res2_w, strides=(1,1,1,1,1)) + conv1_res2_b
		conv1_res2_h = bn(tf.nn.relu(conv1_res2_z), train_mode,"conv1_res2_bn")
		print(conv1_res2_h.shape)
		conv1_res2_h2 = conv1_res2_h + conv1_h
		print(conv1_res2_h2.shape)

		pool1_h = max_pool_2x2x2(conv1_res2_h2)
		print(pool1_h.shape)

		conv2_w = weight_var_selu([5,5,5,96,96],name="conv2_w")
		conv2_b = bias_var([96],name="conv2_b")
		conv2_z = conv3d(pool1_h, conv2_w, strides=(1,2,2,2,1)) + conv2_b
		conv2_h = bn(tf.nn.relu(conv2_z), train_mode, "conv2_bn")
		print(conv2_h.shape)

		conv2_res1_w = weight_var_selu([5,5,5,96,96], name="conv2_res1_w")
		conv2_res1_b = bias_var([96], name="conv2_res1_b")
		conv2_res1_z = conv3d(conv2_h, conv2_res1_w, strides=(1,1,1,1,1)) + conv2_res1_b
		conv2_res1_h = bn(tf.nn.relu(conv2_res1_z), train_mode,"conv2_res1_bn")
		print(conv2_res1_h.shape)
		conv2_res1_h2 = conv2_res1_h + conv2_h
		print(conv2_res1_h2.shape)
		
		conv2_res2_w = weight_var_selu([3,3,3,96,96], name="conv2_res2_w")
		conv2_res2_b = bias_var([96], name="conv2_res2_b")
		conv2_res2_z = conv3d(conv2_res1_h2, conv2_res2_w, strides=(1,1,1,1,1)) + conv2_res2_b
		conv2_res2_h = bn(tf.nn.relu(conv2_res2_z), train_mode,"conv2_res2_bn")
		print(conv2_res2_h.shape)
		conv2_res2_h2 = conv2_res2_h + conv2_h
		print(conv2_res2_h2.shape)

		pool2_h = max_pool_2x2x2(conv2_res2_h2)
		print(pool2_h.shape)

		conv3_w = weight_var_selu([3,3,3,96,128],name="conv3_w")
		conv3_b = bias_var([128],name="conv3_b")
		conv3_z = conv3d(pool2_h, conv3_w, strides=(1,1,1,1,1)) + conv3_b
		conv3_h = bn(tf.nn.relu(conv3_z), train_mode, "conv3_bn")
		print(conv3_h.shape)

		pool3_h = max_pool_2x2x2(conv3_h)
		print(pool3_h.shape)

		pool3_h_dim = (pool3_h.shape[1] * pool3_h.shape[2] * pool3_h.shape[3] * pool3_h.shape[4])
		flatten_h = tf.reshape(pool3_h, [tf.shape(pool3_h)[0], int(pool3_h_dim)], name="flatten_h")
		print(flatten_h.shape)
		
		fc1_w = weight_var([int(flatten_h.shape[1]), 10], stddev=0.01, name="fc1_w")
		fc1_b = bias_var([10], name="fc1_b")
		fc1_z = tf.matmul(flatten_h, fc1_w) + fc1_b
		fc1_h = bn(tf.nn.relu(fc1_z), train_mode, "fc1_bn")
		print(fc1_h.shape)
		
		fc2_w = weight_var([10, 1], stddev=0.01, name="fc2_w")
		fc2_b = bias_var([1], name="fc2_b")
		fc2_z = tf.matmul(fc1_h, fc2_w) + fc2_b
		print(fc2_z.shape)
	
	return fc2_z, [fc1_h, fc1_z, flatten_h, pool3_h, conv3_h, pool2_h, conv2_h, conv1_res2_h2, conv1_res2_h, conv1_res1_h2, conv1_res1_h, conv1_h]


def model_3dcnn_res4(model_name, img_data, train_mode, reuse):
	if feat_tool_ind == 0:
		num_filters = [96, 128, 256, 512]
	else:
		num_filters = [96, 128, 128]
	dropout = 0.5

	with tf.variable_scope(model_name, reuse=reuse):
		x = img_data
		print(x.shape)
		
		conv1_w = weight_var_selu([9,9,9,input_dim[3],num_filters[0]],name="conv1_w")
		conv1_b = bias_var([num_filters[0]],name="conv1_b")
		conv1_z = conv3d(x, conv1_w, strides=(1,3,3,3,1)) + conv1_b
		conv1_h = bn(tf.nn.relu(conv1_z), train_mode,"conv1_bn")
		print(conv1_h.shape)
		
		conv1_res1_w = weight_var_selu([9,9,9,num_filters[0],num_filters[0]], name="conv1_res1_w")
		conv1_res1_b = bias_var([num_filters[0]], name="conv1_res1_b")
		conv1_res1_z = conv3d(conv1_h, conv1_res1_w, strides=(1,1,1,1,1)) + conv1_res1_b
		conv1_res1_h = bn(tf.nn.relu(conv1_res1_z), train_mode,"conv1_res1_bn")
		print(conv1_res1_h.shape)
		conv1_res1_h2 = conv1_res1_h + conv1_h
		print(conv1_res1_h2.shape)
		
		conv1_res2_w = weight_var_selu([9,9,9,num_filters[0],num_filters[0]], name="conv1_res2_w")
		conv1_res2_b = bias_var([num_filters[0]], name="conv1_res2_b")
		conv1_res2_z = conv3d(conv1_res1_h2, conv1_res2_w, strides=(1,1,1,1,1)) + conv1_res2_b
		conv1_res2_h = bn(tf.nn.relu(conv1_res2_z), train_mode,"conv1_res2_bn")
		print(conv1_res2_h.shape)
		conv1_res2_h2 = conv1_res2_h + conv1_res1_h + conv1_h
		print(conv1_res2_h2.shape)
		

		conv2_w = weight_var_selu([7,7,7,num_filters[0],num_filters[1]],name="conv2_w")
		conv2_b = bias_var([num_filters[1]],name="conv2_b")
		conv2_z = conv3d(conv1_res2_h2, conv2_w, strides=(1,3,3,3,1)) + conv2_b
		conv2_h = bn(tf.nn.relu(conv2_z), train_mode, "conv2_bn")
		print(conv2_h.shape)

		conv2_res1_w = weight_var_selu([7,7,7,num_filters[1],num_filters[1]], name="conv2_res1_w")
		conv2_res1_b = bias_var([num_filters[1]], name="conv2_res1_b")
		conv2_res1_z = conv3d(conv2_h, conv2_res1_w, strides=(1,1,1,1,1)) + conv2_res1_b
		conv2_res1_h = bn(tf.nn.relu(conv2_res1_z), train_mode,"conv2_res1_bn")
		print(conv2_res1_h.shape)
		conv2_res1_h2 = conv2_res1_h + conv2_h
		print(conv2_res1_h2.shape)

		conv2_res2_w = weight_var_selu([7,7,7,num_filters[1],num_filters[1]], name="conv2_res2_w")
		conv2_res2_b = bias_var([num_filters[1]], name="conv2_res2_b")
		conv2_res2_z = conv3d(conv2_res1_h2, conv2_res2_w, strides=(1,1,1,1,1)) + conv2_res2_b
		conv2_res2_h = bn(tf.nn.relu(conv2_res2_z), train_mode,"conv2_res2_bn")
		print(conv2_res2_h.shape)
		conv2_res2_h2 = conv2_res2_h + conv2_res1_h + conv2_h
		print(conv2_res2_h2.shape)
		
	
		conv3_w = weight_var_selu([5,5,5,num_filters[1],num_filters[2]],name="conv3_w")
		conv3_b = bias_var([num_filters[2]],name="conv3_b")
		conv3_z = conv3d(conv2_res2_h2, conv3_w, strides=(1,2,2,2,1)) + conv3_b
		conv3_h = bn(tf.nn.dropout(tf.nn.relu(conv3_z), keep_prob=dropout), train_mode, "conv3_bn")
		print(conv3_h.shape)
	
	
		conv4_w = weight_var_selu([3,3,3,num_filters[2],num_filters[3]],name="conv4_w")
		conv4_b = bias_var([num_filters[3]],name="conv4_b")
		conv4_z = conv3d(conv3_h, conv4_w, strides=(1,1,1,1,1)) + conv4_b
		conv4_h = bn(tf.nn.relu(conv4_z), train_mode, "conv4_bn")
		print(conv4_h.shape)

		pool4_h = max_pool_2x2x2(conv4_h)
		print(pool4_h.shape)

		pool4_h_dim = (pool4_h.shape[1] * pool4_h.shape[2] * pool4_h.shape[3] * pool4_h.shape[4])
		flatten_h = tf.reshape(pool4_h, [tf.shape(pool4_h)[0], int(pool4_h_dim)], name="flatten_h")
		print(flatten_h.shape)
		
		#fc1_w = weight_var([int(flatten_h.shape[1]), 2], stddev=0.01, name="fc1_w")
		#fc1_b = bias_var([2], name="fc1_b")
		#fc1_z = tf.matmul(flatten_h, fc1_w) + fc1_b
		#print(fc1_z.shape)
		#return fc1_z
		
		fc1_w = weight_var([int(flatten_h.shape[1]), 50], stddev=0.01, name="fc1_w")
		fc1_b = bias_var([50], name="fc1_b")
		fc1_z = tf.matmul(flatten_h, fc1_w) + fc1_b
		fc1_y = tf.nn.dropout(tf.nn.relu(fc1_z), keep_prob=dropout)
		fc1_h = bn(fc1_y, train_mode, "fc1_bn")
		print(fc1_h.shape)

		
		fc2_w = weight_var([50, 1], stddev=0.01, name="fc2_w")
		fc2_b = bias_var([1], name="fc2_b")
		fc2_z = tf.matmul(fc1_h, fc2_w) + fc2_b
		print(fc2_z.shape)
	
	return fc2_z, [fc1_h, fc1_y, fc1_z, flatten_h]


def model_3dcnn_atomnet(model_name, img_data, train_mode, reuse):
	with tf.variable_scope(model_name, reuse=reuse):
		keep_prob = 0.3
	
		x = img_data
		print(x.shape)
		
		conv1_w = weight_var_selu([5,5,5,input_dim[3],20],name="conv1_w")
		conv1_b = bias_var([20],name="conv1_b")
		conv1_z = conv3d(x, conv1_w, strides=(1,1,1,1,1)) + conv1_b
		conv1_h = tf.nn.relu(conv1_z)
		print(conv1_h.shape)
		
		pool1_h = avg_pool_2x2x2(conv1_h)
		print(pool1_h.shape)
		
		conv2_w = weight_var_selu([3,3,3,20,30],name="conv2_w")
		conv2_b = bias_var([30],name="conv2_b")
		conv2_z = conv3d(pool1_h, conv2_w, strides=(1,1,1,1,1)) + conv2_b
		conv2_h = tf.nn.relu(conv2_z)
		print(conv2_h.shape)
		
		pool2_h = avg_pool_2x2x2(conv2_h)
		print(pool2_h.shape)
		
		conv3_w = weight_var_selu([2,2,2,30,40],name="conv3_w")
		conv3_b = bias_var([40],name="conv3_b")
		conv3_z = conv3d(pool2_h, conv3_w, strides=(1,1,1,1,1)) + conv3_b
		conv3_h = tf.nn.relu(conv3_z)
		print(conv3_h.shape)
		
		pool3_h = avg_pool_2x2x2(conv3_h)
		print(pool3_h.shape)
		
		conv4_w = weight_var_selu([2,2,2,40,50],name="conv4_w")
		conv4_b = bias_var([50],name="conv4_b")
		conv4_z = conv3d(pool3_h, conv4_w, strides=(1,1,1,1,1)) + conv4_b
		conv4_h = tf.nn.relu(conv4_z)
		print(conv4_h.shape)
		
		#pool4_h = avg_pool_2x2x2(conv4_h)
		#print(pool4_h.shape)
		pool4_h = conv4_h
		
		conv5_w = weight_var_selu([2,2,2,50,60],name="conv5_w")
		conv5_b = bias_var([60],name="conv5_b")
		conv5_z = conv3d(pool4_h, conv5_w, strides=(1,1,1,1,1)) + conv5_b
		conv5_h = tf.nn.relu(conv5_z)
		print(conv5_h.shape)
		
		#pool5_h = avg_pool_2x2x2(conv5_h)
		#print(pool5_h.shape)
		pool5_h = conv5_h
		
		pool5_h_dim = (pool5_h.shape[1] * pool5_h.shape[2] * pool5_h.shape[3] * pool5_h.shape[4])
		flatten_h = tf.reshape(pool5_h, [tf.shape(pool5_h)[0], int(pool5_h_dim)], name="flatten_h")
		print(flatten_h.shape)
		
		fc1_w = weight_var([int(flatten_h.shape[1]), 1024], stddev=0.01, name="fc1_w")
		fc1_b = bias_var([1024], name="fc1_b")
		fc1_z = tf.matmul(flatten_h, fc1_w) + fc1_b
		fc1_h = tf.nn.dropout(tf.nn.relu(fc1_z), keep_prob)
		print(fc1_h.shape)

		fc2_w = weight_var([1024, 256], stddev=0.01, name="fc2_w")
		fc2_b = bias_var([256], name="fc2_b")
		fc2_z = tf.matmul(fc1_h, fc2_w) + fc2_b
		fc2_h = tf.nn.relu(fc2_z)
		print(fc2_h.shape)

		fc3_w = weight_var([256, 1], stddev=0.01, name="fc3_w")
		fc3_b = bias_var([1], name="fc3_b")
		fc3_z = tf.matmul(fc2_h, fc3_w) + fc3_b
		print(fc3_z.shape)
	
	return fc3_z, [fc2_h, fc2_z, fc1_h, fc1_z, flatten_h]


def model_snet(model_name, input_data, train_mode, reuse):
	input_data = tf.expand_dims(input_data, -1)

	num_filters = 1024
	filter_size = 1
	
	sequence_length = input_dim[0]
	embedding_size = input_feat_size[feat_tool_ind]
	pooled_outputs = []

	with tf.variable_scope(model_name, reuse=reuse):
		W1 = tf.Variable(tf.truncated_normal((filter_size, embedding_size, 1, num_filters), stddev=0.1), name="W_conv1")
		b1 = bias_var([num_filters],name="b_conv1")
		conv1 = tf.nn.conv2d(input_data, W1, strides=[1, 1, 1, 1], padding="VALID", name="conv1")
		h1 = tf.nn.dropout(tf.nn.relu(tf.nn.bias_add(conv1, b1), name="relu"),keep_prob=1)
		print(h1.shape)

		W2 = tf.Variable(tf.truncated_normal((1, 1, num_filters, num_filters), stddev=0.1), name="W_conv2")
		b2 = bias_var([num_filters],name="b_conv2")
		conv2 = tf.nn.conv2d(h1, W2, strides=[1, 1, 1, 1], padding="VALID", name="conv2")
		h2 = tf.nn.dropout(tf.nn.relu(tf.nn.bias_add(conv2, b2), name="relu"),keep_prob=1)
		print(h2.shape)
		h2_res = h1 + h2
		
		W3 = tf.Variable(tf.truncated_normal((1, 1, num_filters, num_filters), stddev=0.1), name="W_conv3")
		b3 = bias_var([num_filters],name="b_conv3")
		conv3 = tf.nn.conv2d(h2_res, W3, strides=[1, 1, 1, 1], padding="VALID", name="conv3")
		h3 = tf.nn.dropout(tf.nn.relu(tf.nn.bias_add(conv3, b3), name="relu"),keep_prob=1)
		print(h3.shape)
		h3_res = h2_res + h3

		pooled = tf.nn.max_pool(h3_res, ksize=[1, sequence_length - filter_size + 1, 1, 1], strides=[1, 1, 1, 1], padding='VALID', name="pool")
		print(pooled.shape)
	
		pooled_flat = tf.reshape(pooled, [-1, num_filters])
		print(pooled_flat.shape)

		fc1_w = weight_var([int(pooled_flat.shape[1]), 100], stddev=0.01, name="fc1_w")
		fc1_b = bias_var([100], name="fc1_b")
		fc1_z = tf.matmul(pooled_flat, fc1_w) + fc1_b
		fc1_h = bn(tf.nn.relu(fc1_z), train_mode, "fc1_bn")
		print(fc1_h.shape)

		fc2_w = weight_var([100, 10], stddev=0.01, name="fc2_w")
		fc2_b = bias_var([10], name="fc2_b")
		fc2_z = tf.matmul(fc1_h, fc2_w) + fc2_b
		fc2_h = bn(tf.nn.relu(fc2_z), train_mode, "fc2_bn")
		print(fc2_h.shape)
		
		fc3_w = weight_var([10, 1], stddev=0.01, name="fc3_w")
		fc3_b = bias_var([1], name="fc3_b")
		fc3_z = tf.matmul(fc2_h, fc3_w) + fc3_b
		print(fc3_z.shape)
	
	return fc3_z, [fc2_h, fc1_h, pooled_flat]


def run_custom_batch(dnn, sess, saver, batch_ind, batch_size, x_batch, y_batch, custom_vars):
	
	print("[%d] extracting features... " % (batch_ind))
	pred, feat1, feat2 = sess.run([dnn.logit_ph, dnn.user_phs[1], dnn.user_phs[3]], feed_dict={dnn.input_ph: x_batch, dnn.training_phase_ph : 0})
	
	pred_arr = custom_vars[0]
	feat_arr1 = custom_vars[1]
	feat_arr2 = custom_vars[2]

	ind1 = (batch_ind) * batch_size
	ind2 = (batch_ind+1) * batch_size
	pred_arr[ind1:ind2] = pred
	feat_arr1[ind1:ind2,:] = feat1
	feat_arr2[ind1:ind2,:] = feat2

	# custom_vars[0] = pred_arr
	# custom_vars[1] = feat_arr1
	# custom_vars[2] = feat_arr2
	# return custom_vars

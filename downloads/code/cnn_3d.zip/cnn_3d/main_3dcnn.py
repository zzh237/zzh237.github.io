################################################################################
# Copyright 2019-2020 Lawrence Livermore National Security, LLC and other
# Spack Project Developers. See the LICENSE file for details.
# SPDX-License-Identifier: MIT
#
# Fusion models for Atomic and molecular STructures (FAST)
# 3D CNN and modified point-net/sentence-net for binding affinity prediction
################################################################################


# from __future__ import absolute_import
# from __future__ import print_function

import os
import sys
import argparse
import numpy as np
import scipy as sp
import pandas as pd
import tensorflow as tf
import yaml
import h5py
import datetime
import subprocess

from scripts.data_reader import DataReader
from scripts.dnn_general import DNN_General
from model.models_3dcnn import *

config_file_name = '3dcnn.yaml'
timestamp = subprocess.run("date +%b_%d_%y_%H_%M_%s", \
	shell=True, stdout=subprocess.PIPE).stdout.decode('utf-8').rstrip()


def parse_command_line():
    """Parse command line arguments
    """
    parser = argparse.ArgumentParser(description="train pbbinnd")
    parser.add_argument("--timestamp", type=str, default=timestamp, help="number of epochs per checkpoint")                          

    parser.add_argument("--config", type=str, dest="config",
                        default=config_file_name,
                        help="Default configuration file")


	# parser.add_argument('-v', '--verbose', dest='verbose',
    #                     action='store_true',
    #                     help="Verbose message")
    # parser.set_defaults(verbose=False)

    return parser.parse_args()

def main():
	pathname = os.path.dirname(sys.argv[0])   
	cur_dir = os.path.abspath(pathname)
	os.chdir(cur_dir)
	sys.path.append(cur_dir)
	
	args = parse_command_line()
	
	# args = argparse.Namespace(config=config_file_name,)
    
	if args is None or isinstance(args, str):
		namespace = argparse.Namespace()
		if args is None:
			namespace.config = config_file_name
			namespace.timestamp = timestamp
		else:
			namespace.config = args
		args = namespace
    
	file = os.path.join(cur_dir, "config/{}".format(args.config)) 
	with open(file) as f:
		config = yaml.load(f)
    
	for key, value in config.items():
		setattr(args, key, value)

	# setattr(args, 'checkpoint-dir', "pybel_processed_{}_{}".format(args.experiment_name,args.timestamp))
	
	args.feat_suffix = "%s_%s_%s_%s_%s" % \
		(args.target_dataset, args.target_trainval_type, \
			args.feat_tool_list[args.feat_tool_ind], \
				args.feat_type_list[args.feat_type_ind], 
				args.feat_pdbbind_type_list[args.feat_pdbbind_type_ind])
	
	if args.input_3D_atom_radii:
		args._3D_suffix = "%d_radii_sigma%d_rot%d" % \
			(args.input_3D_dim, args.input_3D_sigma, args.input_3D_rotate)
	else:
		args._3D_suffix = "%d_radius%d_sigma%d_rot%d" % \
			(args.input_3D_dim, args.input_3D_atom_radius, \
				args.input_3D_sigma, args.input_3D_rotate)
	
	if args.model_type_ind == 0:
		args.input_dim = [args.input_3D_dim, args.input_3D_dim, \
			args.input_3D_dim, args.input_feat_size[args.feat_tool_ind]]
	elif args.model_type_ind == 1:
		args.input_dim = [1350, args.input_feat_size[args.feat_tool_ind]]  # check csv to check # ligand atoms and pocket atoms

	date_str = args.timestamp
	if args.model_type_ind == 0: #3dcnn
		#args.model_subdir will be the output dir where save the output and model
		args.model_subdir = "%s_%s_%s_result_%s" % \
			(args.feat_suffix, args._3D_suffix, \
				args.model_3dcnn_type_list[args.model_3dcnn_type_ind], date_str)
	elif args.model_type_ind == 1:
		args.model_subdir = "%s_%s_result_%s" % \
			(args.feat_suffix, \
				args.model_snet_type_list[args.model_snet_type_ind], date_str)
	if args.run_mode == 5:
		args.external_feat_prefix = "%s_%s" % (args.feat_suffix, args._3D_suffix)
	else:
		args.external_feat_prefix = "%s_%s" % (args.feat_suffix, args._3D_suffix)

	# # load dataset
	# global input_hds
	data_reader = DataReader(**vars(args))
	
	# # initialize CNN
	if args.model_type_ind == 0:
		if args.model_3dcnn_type_ind == 0:
			model = model_3dcnn
		elif  args.model_3dcnn_type_ind == 1:
			model = model_3dcnn_res
		elif  args.model_3dcnn_type_ind == 2:
			model = model_3dcnn_res2
		elif  args.model_3dcnn_type_ind == 3:
			model = model_3dcnn_res3
		elif  args.model_3dcnn_type_ind == 4:
			model = model_3dcnn_res4
		elif  args.model_3dcnn_type_ind == 5:
			model = model_3dcnn_atomnet
		model_name = args.model_3dcnn_type_list[args.model_3dcnn_type_ind]
	elif args.model_type_ind == 1:
		model = model_snet
		model_name = args.model_snet_type_list[args.model_snet_type_ind]

	cnn = DNN_General(data_reader, model, model_name, \
		output_dir=os.path.join(args.external_dir, args.model_subdir), \
			optimizer_info=args.optimizer_info, decay_info=args.decay_info, \
				model_loss_info=args.loss_info, args = args)
	
	# # train CNN
	if args.run_mode == 1:
		cnn.train(args.epoch_count, args.batch_size, \
			args.online_batch_size, args.save_rate, \
				args.verbose, args.val_each_epoch, 1)
	
	elif args.run_mode == 2:
		cnn.test(1, args.verbose, args.test_save_output)
	
	elif args.run_mode == 3 or args.run_mode == 5:
		if args.run_mode == 3: ## using the trained models from where they saved
			featdir = os.path.join(args.main_dir, args.model_subdir)
		else:
			featdir = os.path.join(args.external_dir, args.model_subdir)

		if len(data_reader.train_list) > 0:
			print("extracting training sample features...")
			data_reader.begin_train(1, shuffle=False)
			## we initialize them as empty data for filling data shortly
			train_pred_arr = np.ndarray(shape=(data_reader.train_batch_count), dtype=np.float32)
			train_feat_arr1 = np.ndarray(shape=(data_reader.train_batch_count, 10), dtype=np.float32)
			train_feat_arr2 = np.ndarray(shape=(data_reader.train_batch_count, 256), dtype=np.float32)
			custom_vars = [train_pred_arr, train_feat_arr1, train_feat_arr2]
			cnn.train_custom(1, False, run_custom_batch, custom_vars)
			# updated_custom_vars = cnn.train_custom(1, False, run_custom_batch, custom_vars)
			# train_pred_arr = updated_custom_vars[0]
			# train_feat_arr1 = updated_custom_vars[1]
			# train_feat_arr2 = updated_custom_vars[2]
			np.save(os.path.join(featdir, '%s_train_pred.npy' % args.external_feat_prefix), train_pred_arr)
			np.save(os.path.join(featdir, '%s_train_fc10.npy' % args.external_feat_prefix), train_feat_arr1)
			np.save(os.path.join(featdir, '%s_train_fc256.npy' % args.external_feat_prefix), train_feat_arr2)
			print("training features saved")

		if len(data_reader.val_list) > 0:
			print("extracting validation sample features...")
			data_reader.begin_val(1)
			val_pred_arr = np.ndarray(shape=(data_reader.val_batch_count), dtype=np.float32)
			val_feat_arr1 = np.ndarray(shape=(data_reader.val_batch_count, 10), dtype=np.float32)
			val_feat_arr2 = np.ndarray(shape=(data_reader.val_batch_count, 256), dtype=np.float32)
			custom_vars = [val_pred_arr, val_feat_arr1, val_feat_arr2]
			cnn.val_custom(1, run_custom_batch, custom_vars)
			np.save(os.path.join(featdir, '%s_val_pred.npy' % args.external_feat_prefix), val_pred_arr)
			np.save(os.path.join(featdir, '%s_val_fc10.npy' % args.external_feat_prefix), val_feat_arr1)
			np.save(os.path.join(featdir, '%s_val_fc256.npy' % args.external_feat_prefix), val_feat_arr2)
			print("validation features saved")

		if len(data_reader.test_list) > 0:
			print("extracting test sample features...")
			data_reader.begin_test(1)
			test_pred_arr = np.ndarray(shape=(data_reader.test_batch_count), dtype=np.float32)
			test_feat_arr1 = np.ndarray(shape=(data_reader.test_batch_count, 10), dtype=np.float32)
			test_feat_arr2 = np.ndarray(shape=(data_reader.test_batch_count, 256), dtype=np.float32)
			custom_vars = [test_pred_arr, test_feat_arr1, test_feat_arr2]
			cnn.test_custom(1, run_custom_batch, custom_vars)
			if len(data_reader.train_list) > 0 or len(data_reader.val_list) > 0:
				np.save(os.path.join(featdir, '%s_test_pred.npy' % args.external_feat_prefix), test_pred_arr)
				np.save(os.path.join(featdir, '%s_test_fc10.npy' % args.external_feat_prefix), test_feat_arr1)
				np.save(os.path.join(featdir, '%s_test_fc256.npy' % args.external_feat_prefix), test_feat_arr2)
			else:
				np.save(os.path.join(featdir, '%s_pred.npy' % args.external_feat_prefix), test_pred_arr)
				np.save(os.path.join(featdir, '%s_fc10.npy' % args.external_feat_prefix), test_feat_arr1)
				np.save(os.path.join(featdir, '%s_fc256.npy' % args.external_feat_prefix), test_feat_arr2)
				with open(os.path.join(featdir, '%s_log' % args.external_feat_prefix), 'w') as f:
					f.write("done\n")

			print("test features saved")

	elif args.run_mode == 4:
		cnn.test(1, args.verbose, args.test_save_output, [], args.external_dir)

	tf.Session().close()
	for ds_ind in range(3):
		if args.input_hds[ds_ind] is not None:
			args.input_hds[ds_ind].close()


if __name__ == '__main__':
	main()


# 3D Convolutional Neural Network (3D-CNN)

This directory contains the source code for the 3D-CNN. In order to train or test a 3D model, use main_3dcnn_pdbbind.py 

